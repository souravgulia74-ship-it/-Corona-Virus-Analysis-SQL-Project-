use corona;
show tables;
SELECT * FROM `corona`.`corona virus dataset`;

#Q1. Write a code to check NULL values

SELECT 
    SUM(CASE WHEN Province IS NULL THEN 1 ELSE 0 END) AS Province_nulls,
    SUM(CASE WHEN `Country/Region` IS NULL THEN 1 ELSE 0 END) AS Country_nulls,
    SUM(CASE WHEN Latitude IS NULL THEN 1 ELSE 0 END) AS Latitude_nulls,
    SUM(CASE WHEN Longitude IS NULL THEN 1 ELSE 0 END) AS Longitude_nulls,
    SUM(CASE WHEN `Date` IS NULL THEN 1 ELSE 0 END) AS Date_nulls,
    SUM(CASE WHEN Confirmed IS NULL THEN 1 ELSE 0 END) AS Confirmed_nulls,
    SUM(CASE WHEN Deaths IS NULL THEN 1 ELSE 0 END) AS Deaths_nulls,
    SUM(CASE WHEN Recovered IS NULL THEN 1 ELSE 0 END) AS Recovered_nulls
FROM `corona`.`corona virus dataset`;

#Q2. If NULL values are present, update them with zeros for all columns

UPDATE `corona`.`corona virus dataset`
SET 
    Province = IFNULL(Province, 0),
    `Country/Region` = IFNULL(`Country/Region`, 0),
    Latitude = IFNULL(Latitude, 0),
    Longitude = IFNULL(Longitude, 0),
    Date = ifnull( Date, 0),
    Confirmed = IFNULL(Confirmed, 0),
    Deaths = IFNULL(Deaths, 0),
    Recovered = IFNULL(Recovered, 0)
WHERE id IS NOT NULL;

SELECT * FROM `corona`.`corona virus dataset`;

#Q3. Check total number of rows

SELECT COUNT(*) AS total_rows FROM `corona`.`corona virus dataset`;

#Q4. Check what is start_date and end_date

SELECT 
    MIN(STR_TO_DATE(`Date`, '%Y-%m-%d')) AS start_date, 
    MAX(STR_TO_DATE(`Date`, '%Y-%m-%d')) AS end_date
FROM `corona`.`corona virus dataset`;

#Q5. Number of months present in dataset

SELECT COUNT(DISTINCT DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m')) AS total_months
FROM `corona`.`corona virus dataset`;

#Q6. Find monthly average for confirmed, deaths, recovered

SELECT 
    DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m') AS month,
    AVG(Confirmed) AS avg_confirmed,
    AVG(Deaths) AS avg_deaths,
    AVG(Recovered) AS avg_recovered
FROM `corona`.`corona virus dataset`
GROUP BY month;

#Q7. Find most frequent value for confirmed, deaths, recovered each month
SELECT month, Confirmed, Deaths, Recovered FROM (
    SELECT 
        DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m') AS month, Confirmed, Deaths, Recovered,
        ROW_NUMBER() OVER (PARTITION BY DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m') 
                           ORDER BY COUNT(*) DESC) AS rn
    FROM `corona`.`corona virus dataset`
    GROUP BY month, Confirmed, Deaths, Recovered
) sub
WHERE rn = 1;

#Q8. Find minimum values for confirmed, deaths, recovered per year

SELECT 
    YEAR(STR_TO_DATE(`Date`, '%Y-%m-%d')) AS year,
    MIN(Confirmed) AS min_confirmed,
    MIN(Deaths) AS min_deaths,
    MIN(Recovered) AS min_recovered
FROM `corona`.`corona virus dataset`
GROUP BY year;

#Q9. Find maximum values of confirmed, deaths, recovered per year

SELECT 
    YEAR(STR_TO_DATE(`Date`, '%Y-%m-%d')) AS year,
    MAX(Confirmed) AS max_confirmed,
    MAX(Deaths) AS max_deaths,
    MAX(Recovered) AS max_recovered
FROM `corona`.`corona virus dataset`
GROUP BY year;

#Q10. The total number of cases of confirmed, deaths, recovered each month

SELECT 
    DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m') AS month,
    SUM(Confirmed) AS total_confirmed,
    SUM(Deaths) AS total_deaths,
    SUM(Recovered) AS total_recovered
FROM `corona`.`corona virus dataset`
GROUP BY month;

#Q11. Check how coronavirus spread out with respect to confirmed cases

SELECT 
    SUM(Confirmed) AS total_confirmed,
    AVG(Confirmed) AS avg_confirmed,
    VAR_POP(Confirmed) AS variance_confirmed,
    STDDEV_POP(Confirmed) AS stdev_confirmed
FROM `corona`.`corona virus dataset`;

#Q12. Check how coronavirus spread out with respect to death cases per month

SELECT 
    DATE_FORMAT(STR_TO_DATE(`Date`, '%Y-%m-%d'), '%Y-%m') AS month,
    SUM(Deaths) AS total_deaths,
    AVG(Deaths) AS avg_deaths,
    VAR_POP(Deaths) AS variance_deaths,
    STDDEV_POP(Deaths) AS stdev_deaths
FROM `corona`.`corona virus dataset`
GROUP BY month;

#Q13. Check how coronavirus spread out with respect to recovered cases

SELECT 
    SUM(Recovered) AS total_recovered,
    AVG(Recovered) AS avg_recovered,
    VAR_POP(Recovered) AS variance_recovered,
    STDDEV_POP(Recovered) AS stdev_recovered
FROM `corona`.`corona virus dataset`;

#Q14. Find country having highest number of confirmed cases

SELECT 
    `Country/Region`, 
    SUM(Confirmed) AS total_confirmed
FROM `corona`.`corona virus dataset`
GROUP BY `Country/Region`
ORDER BY total_confirmed DESC
LIMIT 1;

#Q15. Find country having lowest number of death cases

SELECT 
    `Country/Region`, 
    SUM(Deaths) AS total_deaths
FROM `corona`.`corona virus dataset`
GROUP BY `Country/Region`
ORDER BY total_deaths ASC
LIMIT 1;

#Q16. Find top 5 countries having highest recovered cases

SELECT 
    `Country/Region`, 
    SUM(Recovered) AS total_recovered
FROM `corona`.`corona virus dataset`
GROUP BY `Country/Region`
ORDER BY total_recovered DESC
LIMIT 5;







